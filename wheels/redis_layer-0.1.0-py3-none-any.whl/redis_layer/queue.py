from typing import Optional, Dict, Any, List, Iterable
from dataclasses import dataclass
import json
from datetime import datetime, timedelta
import uuid
from datetime import timezone
import sys


def log_message(message: str, error: bool = False) -> None:
    """
    Helper function to log messages with consistent formatting and automatic flushing.

    Args:
        message: The message to log
        error: Whether this is an error message (default: False)
    """
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    prefix = "ERROR" if error else "INFO"
    sys.stdout.write(f"[{timestamp}] {prefix}: {message}\n")
    sys.stdout.flush()


@dataclass
class Job:
    id: str
    data: Dict[str, Any]
    created_at: str
    processing_started_at: Optional[str] = None
    attempt_count: int = 0

    @classmethod
    def create(cls, data: Dict[str, Any]) -> 'Job':
        return cls(
            id=str(uuid.uuid4()),
            data=data,
            created_at=datetime.now().isoformat(),
            attempt_count=0
        )

    def to_json(self) -> str:
        return json.dumps({
            'id': self.id,
            'data': self.data,
            'created_at': self.created_at,
            'processing_started_at': self.processing_started_at,
            'attempt_count': self.attempt_count
        })

    @classmethod
    def from_json(cls, json_str: str) -> 'Job':
        data = json.loads(json_str)
        return cls(**data)


class RedisQueue:
    """
    A Redis-backed queue that maintains three states for jobs:
    1. Queued (pending)
    2. Processing
    3. Complete (with results)
    """

    def __init__(
            self,
            redis_client,
            name: str,
            max_attempts: Optional[int] = 3,
            processing_timeout: int = 3600  # 1 hour default timeout
    ):
        self.redis = redis_client
        self.name = name
        self.max_attempts = max_attempts
        self.processing_timeout = processing_timeout

        # Queue names
        self._pending = f"{name}:pending"  # List of pending jobs
        self._processing = f"{name}:processing"  # Set of jobs being processed
        self._results = f"{name}:results"  # Hash of job_id -> result

    def add_job(self, data: Dict[str, Any]) -> str:
        """Create and queue a new job."""
        job = Job.create(data)
        self.redis.rpush(self._pending, job.to_json())
        return job.id

    def get_next_job(self) -> Optional[Job]:
        """Get next job from queue and mark it as processing."""
        pipe = self.redis.pipeline()

        # Get the next job
        pipe.lpop(self._pending)
        result = pipe.execute()
        job_json = result[0]

        if not job_json:
            return None

        job = Job.from_json(job_json)
        job.processing_started_at = datetime.now().isoformat()
        job.attempt_count += 1

        # Use transaction to add to processing set
        updated_job_json = job.to_json()
        pipe.sadd(self._processing, updated_job_json)
        pipe.execute()

        return job

    def requeue_job(self, job_id: str, priority: bool = True) -> None:
        """
        Move a job from processing back to pending queue.
        If priority=True, add to front of queue.
        """
        job_json = self._find_and_remove_from_processing(job_id)
        if not job_json:
            raise ValueError(f"Job {job_id} not found in processing set")

        job = Job.from_json(job_json)
        job.attempt_count += 1

        # Check if we've exceeded max attempts
        if self.max_attempts is not None and job.attempt_count >= self.max_attempts:
            log_message(f"Job {job_id} permanently failed after {job.attempt_count} attempts", error=True)
            return

        # Reset processing timestamp
        job.processing_started_at = None

        # Add back to pending queue
        if priority:
            self.redis.lpush(self._pending, job.to_json())
        else:
            self.redis.rpush(self._pending, job.to_json())

    def _get_stuck_jobs(self) -> List[str]:
        """
        Check for jobs that have been processing for too long.
        Returns list of stuck job IDs.
        """
        stuck_jobs = []
        timeout_threshold = datetime.now() - timedelta(seconds=self.processing_timeout)

        for job_json in self.redis.smembers(self._processing):
            job = Job.from_json(job_json)
            if job.processing_started_at:
                started_at = datetime.fromisoformat(job.processing_started_at)
                if started_at < timeout_threshold:
                    stuck_jobs.append(job.id)

        return stuck_jobs

    def handle_stuck_jobs(self, requeue: bool = True) -> List[str]:
        """
        Find and handle stuck jobs.
        If requeue=True, puts them back in pending queue.
        Returns list of handled job IDs.
        """
        stuck_jobs = self._get_stuck_jobs()
        for job_id in stuck_jobs:
            if requeue:
                log_message(f"Requeuing stuck job {job_id}")
                self.requeue_job(job_id, priority=False)
            else:
                log_message(f"Removing stuck job {job_id} from processing set")
                self._find_and_remove_from_processing(job_id)

        return stuck_jobs

    def complete_job(self, job_id: str, result: Dict[str, Any]) -> None:
        """Mark a job as complete with its result."""
        log_message(f"Completing job {job_id}")
        job_json = self._find_and_remove_from_processing(job_id)
        if not job_json:
            raise ValueError(f"Job {job_id} not found in processing set")

        # Store result
        self.redis.hset(self._results, job_id, json.dumps(result))

    def report_job_failure(self, job_id: str, error: str) -> None:
        """
        Mark a job as failed and requeue it unless max attempts are exceeded.
        Increments the attempt count and requeues the job if under max_attempts.
        """
        log_message(f"Failing job {job_id}: {error}")

        # Get the job from processing without removing it yet
        job_json = None
        for processing_job_json in self.redis.smembers(self._processing):
            job = Job.from_json(processing_job_json)
            if job.id == job_id:
                job_json = processing_job_json
                break

        if not job_json:
            raise ValueError(f"Job {job_id} not found in processing set")

        job = Job.from_json(job_json)

        if self.max_attempts is not None and job.attempt_count >= self.max_attempts:
            self.redis.srem(self._processing, job_json)
            log_message(f"Job {job_id} permanently failed after {job.attempt_count} attempts: {error}")
        else:
            job.processing_started_at = None
            self.requeue_job(job_id, priority=False)
            max_attempts_string = str(self.max_attempts or "unlimited")
            log_message(f"Requeueing failed job {job_id} (attempt {job.attempt_count}/{max_attempts_string})")

    def get_job_state(self, job_id: str) -> Optional[str]:
        """
        Get the current state of a job:
        'pending', 'processing', 'complete', or None if not found
        """
        # Check pending queue
        for job_json in self.redis.lrange(self._pending, 0, -1):
            if Job.from_json(job_json).id == job_id:
                return 'pending'

        # Check processing set
        for job_json in self.redis.smembers(self._processing):
            if Job.from_json(job_json).id == job_id:
                return 'processing'

        # Check results
        if self.redis.hexists(self._results, job_id):
            return 'complete'

        return None

    def cleanup_job(self, job_id: str) -> None:
        """
        Remove all traces of a job from the queue.
        Useful for cleanup or error handling.
        """
        # Remove from results
        self.redis.hdel(self._results, job_id)

        # Remove from all other possible locations
        for job_json in self.redis.lrange(self._pending, 0, -1):
            job = Job.from_json(job_json)
            if job.id == job_id:
                self.redis.lrem(self._pending, 0, job_json)

        self._find_and_remove_from_processing(job_id)

    def get_all_job_ids(self) -> List[str]:
        all_ids = []
        for job_json in self.redis.lrange(self._pending, 0, -1):
            job_id = Job.from_json(job_json).id
            all_ids.append(job_id)

        for job_json in self.redis.smembers(self._processing):
            job_id = Job.from_json(job_json).id
            all_ids.append(job_id)

        all_ids.extend (self.redis.hkeys(self._results))

        return all_ids

    def get_result(self, job_id: str) -> Optional[Dict[str, Any]]:
        """Get the result of a completed job if it exists."""
        result_json = self.redis.hget(self._results, job_id)
        return json.loads(result_json) if result_json else None

    def _find_and_remove_from_processing(self, job_id: str) -> Optional[str]:
        """Find a job in the processing set and remove it."""
        for job_json in self.redis.smembers(self._processing):
            job = Job.from_json(job_json)
            if job.id == job_id:
                self.redis.srem(self._processing, job_json)
                return job_json
        return None



    def __str__(self) -> str:
        """Return a string representation of the queue's current state."""
        output = []
        
        # Add pending jobs
        pending_jsons = self.redis.lrange(self._pending, 0, -1)
        if len(pending_jsons) > 0:
            output.append("PENDING:")
            for job_json in pending_jsons:
                output.append(repr(job_json))
        
        # Add processing jobs
        processing_jsons = self.redis.smembers(self._processing)
        if len(processing_jsons) > 0:
            output.append("PROCESSING:")
            for job_json in processing_jsons:
                output.append(repr(job_json))
        
        # Add complete jobs
        complete_ids = self.redis.hkeys(self._results)
        if len(complete_ids) > 0:
            output.append("COMPLETE:")
            for job_id in complete_ids:
                output.append(f'{job_id}: {self.get_result(job_id)}')
        
        return "\n".join(output)
